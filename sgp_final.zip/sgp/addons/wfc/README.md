# WFC (Wave Function Collapse) and generic constraint-solving implementation for Godot 4

[Read more](https://github.com/AlexeyBond/godot-constraint-solving#readme).
