This folder contains:
	ReadMe						To see Intstructions
	Folder Result Playtest		To see the raw data from the ingame events
	RawdataQuestionaire 		To see the raw data from the questionaires of all players
	noguide/withguide 			The raw data from the questionaire in computer readable form
	WithGuides/WithoutGuides	The Game with guides or without

	Not include but very usefull is the program to evaluate the raw data
	https://github.com/David-hub0/BachelorDataEvaluation.git